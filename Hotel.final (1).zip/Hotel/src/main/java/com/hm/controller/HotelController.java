package com.hm.controller;

import com.hm.dto.ApiResponse;
import com.hm.dto.HotelDTO;
import com.hm.service.HotelService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/hotels")
public class HotelController {

    @Autowired
    private HotelService hotelService;

    @PostMapping("/post")
    public ResponseEntity<ApiResponse> addHotel(@Valid @RequestBody HotelDTO hotelDTO) {
        Optional<String> error = hotelService.addHotel(hotelDTO);
        if (error.isPresent()) {
            return ResponseEntity.badRequest().body(new ApiResponse("ADDFAILS", error.get()));
        }
        return ResponseEntity.ok(new ApiResponse("POSTSUCCESS", "Hotel added successfully"));
    }

    @GetMapping("/all")
    public ResponseEntity<ApiResponse> getAllHotels() {
        List<HotelDTO> hotels = hotelService.getAllHotels();
        if (hotels.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(new ApiResponse("GETFAILS", "Hotel list is empty"));
        }
        return ResponseEntity.ok(new ApiResponse("GETALLSUCCESS", "Hotels retrieved successfully", hotels));
    }

    @GetMapping("/{hotelId}")
    public ResponseEntity<ApiResponse> getHotelById(@PathVariable("hotelId") Integer hotelId) {
        Optional<HotelDTO> hotel = hotelService.getHotelById(hotelId);
        return hotel.map(value ->
                        ResponseEntity.ok(new ApiResponse("GETSUCCESS", "Hotel found", value)))
                .orElse(ResponseEntity.badRequest()
                        .body(new ApiResponse("GETFAILS", "Hotel doesn't exist")));
    }

    @GetMapping("/description/{description}")
    public ResponseEntity<ApiResponse> getHotelsByDescription(@PathVariable("description") String description) {
        List<HotelDTO> hotels = hotelService.getHotelsByDescription(description);
        if (hotels.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(new ApiResponse("GETFAILS", "No hotel found with the specific description"));
        }
        return ResponseEntity.ok(new ApiResponse("GETSUCCESS", "Hotels retrieved successfully", hotels));
    }

    @GetMapping("/name/{name}")
    public ResponseEntity<ApiResponse> getHotelsByName(@PathVariable("name") String name) {
        if (name == null || name.trim().isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(new ApiResponse("INPUTFAIL", "Hotel name cannot be empty"));
        }
        List<HotelDTO> hotels = hotelService.getHotelsByName(name);
        if (hotels.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(new ApiResponse("GETFAILS", "No hotel found with the specific name"));
        }
        return ResponseEntity.ok(new ApiResponse("GETSUCCESS", "Hotels retrieved successfully", hotels));
    }

    @PutMapping("/update/{hotelId}")
    public ResponseEntity<ApiResponse> updateHotel(@PathVariable("hotelId") Integer hotelId,
                                                   @Valid @RequestBody HotelDTO hotelDTO) {
        Optional<String> error = hotelService.updateHotel(hotelId, hotelDTO);

        if (error.isPresent()) {
            return ResponseEntity.badRequest()
                    .body(new ApiResponse("UPDATEFAIL", error.get()));
        }

        return ResponseEntity.ok(new ApiResponse("UPDATESUCCESS", "Hotel updated successfully"));
    }
    
    @DeleteMapping("/delete/{hotelId}")
    public ResponseEntity<ApiResponse> deleteHotelById(@PathVariable("hotelId") Integer hotelId) {
        Optional<String> error = hotelService.deleteHotelById(hotelId);

        if (error.isPresent()) {
            return ResponseEntity.badRequest()
                    .body(new ApiResponse("DELETEFAIL", error.get()));
        }

        return ResponseEntity.ok(new ApiResponse("DELETESUCCESS", "Hotel deleted successfully"));
    }



//    @GetMapping("/amenity/{amenityId}")
//    public ResponseEntity<ApiResponse> getHotelsByAmenity(@PathVariable("amenityId") Integer amenityId) {
//        List<HotelDTO> hotels = hotelService.getHotelsByAmenityId(amenityId);
//        if (hotels.isEmpty()) {
//            return ResponseEntity.badRequest()
//                    .body(new ApiResponse("GETFAILS", "No hotel found with the specific amenity"));
//        }
//        return ResponseEntity.ok(new ApiResponse("GETSUCCESS", "Hotels retrieved successfully", hotels));
//    }
}
