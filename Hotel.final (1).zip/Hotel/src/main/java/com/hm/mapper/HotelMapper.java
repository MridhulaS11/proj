package com.hm.mapper;

import com.hm.dto.HotelDTO;
import com.hm.entity.Hotel;

public class HotelMapper {

    // Convert Entity to DTO
    public static HotelDTO toDTO(Hotel hotel) {
        if (hotel == null) {
            return null;
        }
        return new HotelDTO(
                hotel.getHotel_id(),
                hotel.getName(),
                hotel.getLocation(),
                hotel.getDescription()
        );
    }

    // Convert DTO to Entity
    public static Hotel toEntity(HotelDTO hotelDTO) {
        if (hotelDTO == null) {
            return null;
        }
        Hotel hotel = new Hotel();
        hotel.setHotel_id(hotelDTO.getHotel_id());  // this is optional if your id is generated
        hotel.setName(hotelDTO.getName());
        hotel.setLocation(hotelDTO.getLocation());
        hotel.setDescription(hotelDTO.getDescription());
        return hotel;
    }
}
