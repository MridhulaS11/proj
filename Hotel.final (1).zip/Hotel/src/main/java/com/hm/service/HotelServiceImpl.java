package com.hm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hm.dto.HotelDTO;
import com.hm.entity.Hotel;
import com.hm.mapper.HotelMapper;
import com.hm.repository.HotelRepository;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.hm.mapper.HotelMapper.*;

@Service
public class HotelServiceImpl implements HotelService {

    @Autowired
    private HotelRepository hotelRepository;

    @Override
    public Optional<String> addHotel(HotelDTO hotelDTO) {
        if (hotelDTO.getName().length() < 3) {
            return Optional.of("Hotel name must be at least 3 characters long");
        }

        Optional<Hotel> existingHotel = hotelRepository.findByName(hotelDTO.getName());
        if (existingHotel.isPresent()) {
            return Optional.of("Hotel already exists");
        }

        Hotel hotel = toEntity(hotelDTO);
        hotelRepository.save(hotel);
        return Optional.empty();  // Success (no error message)
    }

    @Override
    public List<HotelDTO> getAllHotels() {
        return hotelRepository.findAll()
                .stream()
                .map(HotelMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<HotelDTO> getHotelById(Integer hotel_id) {
        return hotelRepository.findById(hotel_id)
                .map(HotelMapper::toDTO);
    }

    @Override
    public Optional<String> updateHotel(Integer hotel_id, HotelDTO hotelDTO) {
        Optional<Hotel> hotelOpt = hotelRepository.findById(hotel_id);

        if (hotelOpt.isPresent()) {
            Hotel updatedHotel = hotelOpt.get();
            updatedHotel.setName(hotelDTO.getName());
            updatedHotel.setLocation(hotelDTO.getLocation());
            updatedHotel.setDescription(hotelDTO.getDescription());
            hotelRepository.save(updatedHotel);

            return Optional.empty();  // Success (no error message)
        }

        return Optional.of("Hotel with ID " + hotel_id + " doesn't exist");
    }

    @Override
    public List<HotelDTO> getHotelsByDescription(String description) {
        if (description == null || description.trim().isEmpty()) {
            return Collections.emptyList();
        }

        return hotelRepository.findByDescriptionContaining(description)
                .stream()
                .map(HotelMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<HotelDTO> getHotelsByName(String name) {
        return hotelRepository.findByNameContainingIgnoreCase(name)
                .stream()
                .map(HotelMapper::toDTO)
                .collect(Collectors.toList());
    }
    
    public Optional<String> deleteHotelById(Integer hotelId) {
        Optional<HotelDTO> existingHotel = getHotelById(hotelId);

        if (existingHotel.isEmpty()) {
            return Optional.of("Hotel with ID " + hotelId + " not found");
        }

        hotelRepository.deleteById(hotelId);
        return Optional.empty();
    }


//    @Override
//    public List<HotelDTO> getHotelsByAmenityId(Integer amenityId) {
//        return hotelRepository.findHotelsByAmenityId(amenityId)
//                .stream()
//                .map(HotelMapper::toDTO)
//                .collect(Collectors.toList());
//    }
}
