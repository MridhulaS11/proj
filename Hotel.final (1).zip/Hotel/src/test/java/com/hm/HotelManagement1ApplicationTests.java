package com.hm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelManagement1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
