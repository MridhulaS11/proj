package  com.hm.hotelservice;

import com.hm.dto.HotelDTO;
import com.hm.entity.Hotel;
import com.hm.repository.HotelRepository;
import com.hm.service.HotelServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;


import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class HotelServiceTest {

    @Mock
    private HotelRepository hotelRepository;

    @InjectMocks
    private HotelServiceImpl hotelService;

    private HotelDTO hotelDTO;
    private Hotel hotel;

    @BeforeEach
    void setUp() {
        hotelDTO = new HotelDTO();
        hotelDTO.setName("Luxury Inn");
        hotelDTO.setLocation("New York");
        hotelDTO.setDescription("A luxury hotel");

        hotel = new Hotel();
        hotel.setHotel_id(1);
        hotel.setName(hotelDTO.getName());
        hotel.setLocation(hotelDTO.getLocation());
        hotel.setDescription(hotelDTO.getDescription());
    }

    @Test
    void addHotel_Success() {
        when(hotelRepository.findByName(hotelDTO.getName())).thenReturn(Optional.empty());
        when(hotelRepository.save(any(Hotel.class))).thenReturn(hotel);

        Optional<String> result = hotelService.addHotel(hotelDTO);

        assertTrue(result.isEmpty());
        verify(hotelRepository).findByName(hotelDTO.getName());
        verify(hotelRepository).save(any(Hotel.class));
    }

    @Test
    void addHotel_Fail_NameTooShort() {
        hotelDTO.setName("A");

        Optional<String> result = hotelService.addHotel(hotelDTO);

        assertTrue(result.isPresent());
        assertEquals("Hotel name must be at least 3 characters long", result.get());
        verifyNoInteractions(hotelRepository);  // No DB call since validation failed
    }

    @Test
    void addHotel_Fail_AlreadyExists() {
        when(hotelRepository.findByName(hotelDTO.getName())).thenReturn(Optional.of(hotel));

        Optional<String> result = hotelService.addHotel(hotelDTO);

        assertTrue(result.isPresent());
        assertEquals("Hotel already exists", result.get());
        verify(hotelRepository).findByName(hotelDTO.getName());
        verifyNoMoreInteractions(hotelRepository);
    }

    @Test
    void getAllHotels_Success() {
        when(hotelRepository.findAll()).thenReturn(Collections.singletonList(hotel));

        List<HotelDTO> hotels = hotelService.getAllHotels();

        assertEquals(1, hotels.size());
        assertEquals("Luxury Inn", hotels.get(0).getName());
        verify(hotelRepository).findAll();
    }

    @Test
    void getHotelById_Found() {
        when(hotelRepository.findById(1)).thenReturn(Optional.of(hotel));

        Optional<HotelDTO> result = hotelService.getHotelById(1);

        assertTrue(result.isPresent());
        assertEquals("Luxury Inn", result.get().getName());
        verify(hotelRepository).findById(1);
    }

    @Test
    void getHotelById_NotFound() {
        when(hotelRepository.findById(1)).thenReturn(Optional.empty());

        Optional<HotelDTO> result = hotelService.getHotelById(1);

        assertTrue(result.isEmpty());
        verify(hotelRepository).findById(1);
    }

    @Test
    void updateHotel_Success() {
        when(hotelRepository.findById(1)).thenReturn(Optional.of(hotel));
        when(hotelRepository.save(any(Hotel.class))).thenReturn(hotel);

        Optional<String> result = hotelService.updateHotel(1, hotelDTO);

        assertTrue(result.isEmpty());
        verify(hotelRepository).findById(1);
        verify(hotelRepository).save(any(Hotel.class));
    }

    @Test
    void updateHotel_NotFound() {
        when(hotelRepository.findById(1)).thenReturn(Optional.empty());

        Optional<String> result = hotelService.updateHotel(1, hotelDTO);

        assertTrue(result.isPresent());
        assertEquals("Hotel with ID 1 doesn't exist", result.get());
        verify(hotelRepository).findById(1);
        verifyNoMoreInteractions(hotelRepository);
    }

    @Test
    void getHotelsByDescription_Found() {
        when(hotelRepository.findByDescriptionContaining("luxury"))
                .thenReturn(Collections.singletonList(hotel));

        List<HotelDTO> hotels = hotelService.getHotelsByDescription("luxury");

        assertEquals(1, hotels.size());
        assertEquals("Luxury Inn", hotels.get(0).getName());
        verify(hotelRepository).findByDescriptionContaining("luxury");
    }

    @Test
    void getHotelsByDescription_EmptyInput() {
        List<HotelDTO> hotels = hotelService.getHotelsByDescription("");

        assertTrue(hotels.isEmpty());
        verifyNoInteractions(hotelRepository);
    }

    @Test
    void getHotelsByName_Success() {
        when(hotelRepository.findByNameContainingIgnoreCase("lux"))
                .thenReturn(Collections.singletonList(hotel));

        List<HotelDTO> hotels = hotelService.getHotelsByName("lux");

        assertEquals(1, hotels.size());
        assertEquals("Luxury Inn", hotels.get(0).getName());
        verify(hotelRepository).findByNameContainingIgnoreCase("lux");
    }
}
