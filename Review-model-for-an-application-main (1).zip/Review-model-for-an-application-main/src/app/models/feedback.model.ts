export interface Feedback {
  overallRating: number;
  categories: any;
  name: string;
  rating: number;
  comment: string;
  suggestions: string;
}