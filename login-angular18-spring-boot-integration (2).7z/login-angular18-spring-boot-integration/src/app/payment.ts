export class Payment {
    id?: number;
    amount: number | undefined;
    status: string | undefined;
}
