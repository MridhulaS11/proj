import { Component, OnInit } from '@angular/core';
import { PaymentService } from '../payment.service';
import { Payment } from '../payment';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  payments: Payment[] = [];
  newPayment: Payment = new Payment();
  totalRevenue: number = 0;

  constructor(private paymentService: PaymentService) {}

  ngOnInit(): void {
    this.getAllPayments();
    this.getTotalRevenue();
  }

  createPayment(): void {
    this.paymentService.createPayment(this.newPayment).subscribe(() => {
      this.getAllPayments();
      this.getTotalRevenue();
      this.newPayment = new Payment();
    });
  }

  getAllPayments(): void {
    this.paymentService.getAllPayments().subscribe((data: Payment[]) => {
      this.payments = data;
    });
  }

  getTotalRevenue(): void {
    this.paymentService.getTotalRevenue().subscribe((data: number) => {
      this.totalRevenue = data;
    });
  }

  downloadPaymentProof(payment: Payment): void {
    const proof = `Payment ID: ${payment.id}\nAmount: ${payment.amount}\nStatus: ${payment.status}`;
    const blob = new Blob([proof], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `payment-proof-${payment.id}.txt`;
    a.click();
    window.URL.revokeObjectURL(url);
  }
}
